﻿using System;
using System.Collections.Generic;

class Edge
{
    public int Source { get; set; }
    public int Destination { get; set; }
    public int Weight { get; set; }

    public Edge(int source, int destination, int weight)
    {
        Source = source;
        Destination = destination;
        Weight = weight;
    }
}

class Graph
{
    private int _vertices;
    private List<Edge> _edges;

    public Graph(int vertices)
    {
        _vertices = vertices;
        _edges = new List<Edge>();
    }

    public void AddEdge(int source, int destination, int weight)
    {
        _edges.Add(new Edge(source, destination, weight));
    }

    public void BellmanFord(int startVertex)
    {
        int[] distances = new int[_vertices];
        for (int i = 0; i < _vertices; i++)
            distances[i] = int.MaxValue;

        distances[startVertex] = 0;

        // Relax edges |V| - 1 times
        for (int i = 1; i < _vertices; i++)
        {
            foreach (var edge in _edges)
            {
                if (distances[edge.Source] != int.MaxValue &&
                    distances[edge.Source] + edge.Weight < distances[edge.Destination])
                {
                    distances[edge.Destination] = distances[edge.Source] + edge.Weight;
                }
            }
        }

        // Check for negative-weight cycles
        foreach (var edge in _edges)
        {
            if (distances[edge.Source] != int.MaxValue &&
                distances[edge.Source] + edge.Weight < distances[edge.Destination])
            {
                Console.WriteLine("Graph contains negative weight cycle");
                return;
            }
        }

        PrintSolution(distances);
    }

    private void PrintSolution(int[] distances)
    {
        Console.WriteLine("Vertex Distance from Source");
        for (int i = 0; i < _vertices; i++)
        {
            Console.WriteLine($"{i}\t\t{distances[i]}");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Graph graph = new Graph(5);
        graph.AddEdge(0, 1, -1);
        graph.AddEdge(0, 2, 4);
        graph.AddEdge(1, 2, 3);
        graph.AddEdge(1, 3, 2);
        graph.AddEdge(1, 4, 2);
        graph.AddEdge(3, 2, 5);
        graph.AddEdge(3, 1, 1);
        graph.AddEdge(4, 3, -3);

        graph.BellmanFord(0);

        // Пример с отрицательным циклом
        Graph graphWithNegativeCycle = new Graph(3);
        graphWithNegativeCycle.AddEdge(0, 1, 1);
        graphWithNegativeCycle.AddEdge(1, 2, -1);
        graphWithNegativeCycle.AddEdge(2, 0, -1);

        graphWithNegativeCycle.BellmanFord(0);
    }
}
