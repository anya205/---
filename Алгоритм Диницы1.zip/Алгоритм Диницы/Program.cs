﻿using System;
using System.Collections.Generic;

class Edge
{
    public int To, Flow, Capacity, ReverseIndex;

    public Edge(int to, int capacity, int reverseIndex)
    {
        To = to;
        Capacity = capacity;
        Flow = 0;
        ReverseIndex = reverseIndex;
    }
}

class Dinic
{
    private List<List<Edge>> graph;
    private int[] level;
    private int[] ptr;
    private int source, sink;

    public Dinic(int size)
    {
        graph = new List<List<Edge>>(size);
        for (int i = 0; i < size; i++)
            graph.Add(new List<Edge>());
    }

    public void AddEdge(int from, int to, int capacity)
    {
        graph[from].Add(new Edge(to, capacity, graph[to].Count));
        graph[to].Add(new Edge(from, 0, graph[from].Count - 1)); // обратное ребро
    }

    private bool BFS()
    {
        level = new int[graph.Count];
        Queue<int> queue = new Queue<int>();
        queue.Enqueue(source);
        level[source] = 1;

        while (queue.Count > 0)
        {
            int node = queue.Dequeue();

            foreach (var edge in graph[node])
            {
                if (level[edge.To] == 0 && edge.Flow < edge.Capacity)
                {
                    level[edge.To] = level[node] + 1;
                    queue.Enqueue(edge.To);
                    if (edge.To == sink)
                        return true;
                }
            }
        }
        return false;
    }

    private int DFS(int node, int flow)
    {
        if (node == sink)
            return flow;

        while (ptr[node] < graph[node].Count)
        {
            var edge = graph[node][ptr[node]];

            if (level[edge.To] == level[node] + 1 && edge.Flow < edge.Capacity)
            {
                int pushedFlow = DFS(edge.To, Math.Min(flow, edge.Capacity - edge.Flow));
                if (pushedFlow > 0)
                {
                    edge.Flow += pushedFlow;
                    graph[edge.To][edge.ReverseIndex].Flow -= pushedFlow;
                    return pushedFlow;
                }
            }
            ptr[node]++;
        }
        return 0;
    }

    public int MaxFlow(int s, int t)
    {
        source = s;
        sink = t;
        int totalFlow = 0;

        while (BFS())
        {
            ptr = new int[graph.Count];
            while (true)
            {
                int flow = DFS(source, int.MaxValue);
                if (flow == 0)
                    break;
                totalFlow += flow;
            }
        }

        return totalFlow;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Dinic dinic = new Dinic(6); // количество вершин

        dinic.AddEdge(0, 1, 16);
        dinic.AddEdge(0, 2, 13);
        dinic.AddEdge(1, 2, 10);
        dinic.AddEdge(1, 3, 12);
        dinic.AddEdge(2, 1, 4);
        dinic.AddEdge(2, 4, 14);
        dinic.AddEdge(3, 2, 9);
        dinic.AddEdge(3, 5, 20);
        dinic.AddEdge(4, 3, 7);
        dinic.AddEdge(4, 5, 4);

        int maxFlow = dinic.MaxFlow(0, 5); // от источника к стоку
        Console.WriteLine("Максимальный поток: " + maxFlow);
    }
}
