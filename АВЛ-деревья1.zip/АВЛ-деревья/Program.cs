﻿using System;

class AVLTreeNode
{
    public int Key;
    public AVLTreeNode Left;
    public AVLTreeNode Right;
    public int Height;

    public AVLTreeNode(int key)
    {
        Key = key;
        Height = 1; // Новые узлы добавляются как листовые узлы
    }
}

class AVLTree
{
    private int GetHeight(AVLTreeNode node)
    {
        return node == null ? 0 : node.Height;
    }

    private int GetBalance(AVLTreeNode node)
    {
        return node == null ? 0 : GetHeight(node.Left) - GetHeight(node.Right);
    }

    private AVLTreeNode RightRotate(AVLTreeNode y)
    {
        AVLTreeNode x = y.Left;
        AVLTreeNode T2 = x.Right;

        // Выполнение поворота
        x.Right = y;
        y.Left = T2;

        // Обновление высоты
        y.Height = Math.Max(GetHeight(y.Left), GetHeight(y.Right)) + 1;
        x.Height = Math.Max(GetHeight(x.Left), GetHeight(x.Right)) + 1;

        return x; // Возвращаем новый корень
    }

    private AVLTreeNode LeftRotate(AVLTreeNode x)
    {
        AVLTreeNode y = x.Right;
        AVLTreeNode T2 = y.Left;

        // Выполнение поворота
        y.Left = x;
        x.Right = T2;

        // Обновление высоты
        x.Height = Math.Max(GetHeight(x.Left), GetHeight(x.Right)) + 1;
        y.Height = Math.Max(GetHeight(y.Left), GetHeight(y.Right)) + 1;

        return y; // Возвращаем новый корень
    }

    public AVLTreeNode Insert(AVLTreeNode node, int key)
    {
        // Выполнение обычной вставки BST
        if (node == null)
            return new AVLTreeNode(key);

        if (key < node.Key)
            node.Left = Insert(node.Left, key);
        else if (key > node.Key)
            node.Right = Insert(node.Right, key);
        else // Дубликаты не допускаются
            return node;

        // Обновление высоты этого узла предка
        node.Height = 1 + Math.Max(GetHeight(node.Left), GetHeight(node.Right));


        // Получение баланса этого узла, чтобы проверить, стал ли он несбалансированным
        int balance = GetBalance(node);

        // Если этот узел стал несбалансированным, то есть 4 случая

        // Левый Левый случай
        if (balance > 1 && key < node.Left.Key)
            return RightRotate(node);

        // Правый Правый случай
        if (balance < -1 && key > node.Right.Key)
            return LeftRotate(node);

        // Левый Правый случай
        if (balance > 1 && key > node.Left.Key)
        {
            node.Left = LeftRotate(node.Left);
            return RightRotate(node);
        }

        // Правый Левый случай
        if (balance < -1 && key < node.Right.Key)
        {
            node.Right = RightRotate(node.Right);
            return LeftRotate(node);
        }

        return node; // Возвращаем (неизмененный) узел указателя
    }

    public int GetTreeHeight(AVLTreeNode node)
    {
        return GetHeight(node);
    }
}

class Program
{
    static void Main()
    {
        AVLTree avlTree = new AVLTree();
        AVLTreeNode root = null;

        // Вставка узлов в AVL-дерево
        root = avlTree.Insert(root, 10);
        root = avlTree.Insert(root, 20);
        root = avlTree.Insert(root, 30);
        root = avlTree.Insert(root, 40);
        root = avlTree.Insert(root, 50);
        root = avlTree.Insert(root, 25);

        Console.WriteLine("Высота AVL-дерева: " + avlTree.GetTreeHeight(root));
    }
}
